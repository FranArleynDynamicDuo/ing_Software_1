# SAGE
Sprint 1:

Se creo una rama llamada BilleteraElectrónica, en esta se añadio una
forma de pago alterna a las previamente establecidas.
En la rama master se extrajo la clase propietario de la clase 
llamada estacionamiento.
El merge entre estas dos ramas queda pendiente debido a problemas con 
la herramienta de merge de Egit.
